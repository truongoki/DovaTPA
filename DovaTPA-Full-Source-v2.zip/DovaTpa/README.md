# DovaTPA

Plugin TPA co Dialog UI, danh cho Paper/Folia 1.21.11, Java 21.

## Lenh
- `/tpa` hoac `/tpagui`: mo Dialog UI danh sach nguoi choi.
- `/tpa <ten>`: gui TPA truc tiep.
- `/tpahere <ten>` hoac `/tpalai <ten>`: moi nguoi choi dich chuyen den cho ban.
- `/tpaccept [ten]`, `/yes`, `/tpachapnhan`: chap nhan.
- `/tpahuy`, `/no`: huy cac yeu cau.
- `/tpaauto` hoac `/tpalientuc`: bat/tat tu dong chap nhan.
- `/dova`: xem huong dan.

## Build tren GitHub bang dien thoai
1. Tao repository GitHub moi.
2. Giai nen ZIP nay.
3. Upload TOAN BO noi dung ben trong thu muc `DovaTPA-Source-Full` len repository, bao gom thu muc `.github`.
4. Commit changes vao nhanh `main`.
5. Mo tab Actions, chon workflow `Build DovaTPA`, bam Run workflow neu workflow chua tu chay.
6. Mo job vua chay, tai Artifact `DovaTPA`. Ben trong co file JAR.

## Luu y
Dialog UI la tinh nang Minecraft 1.21.6 tro len; nguoi choi can dung client ho tro Dialog. `folia-supported: true` khai bao ho tro Folia; can kiem thu tren server thuc te truoc khi dua vao su dung chinh thuc.
