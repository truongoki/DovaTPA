package me.truongnho.dovatpa;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import io.papermc.paper.registry.data.dialog.action.ClickCallback;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DovaTPA extends JavaPlugin {
    private enum RequestType { TPA, HERE }
    private record TpaRequest(UUID sender, UUID receiver, RequestType type, long createdAt) {}

    private final Map<UUID, Map<UUID, TpaRequest>> requests = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> autoAccept = new ConcurrentHashMap<>();
    private static final long REQUEST_LIFETIME_MS = 60_000L;

    @Override
    public void onEnable() {
        getLogger().info("DovaTPA da bat - Phat trien boi Truongnho_em");
    }

    @Override
    public void onDisable() {
        requests.clear();
        autoAccept.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Lenh nay chi danh cho nguoi choi.");
            return true;
        }
        if (!player.hasPermission("dovatpa.use")) {
            tell(player, "Ban khong co quyen su dung lenh nay.", NamedTextColor.RED);
            return true;
        }

        switch (command.getName().toLowerCase()) {
            case "tpa", "tpagui" -> {
                if (args.length == 0) openPlayerDialog(player, RequestType.TPA);
                else sendToNamedPlayer(player, args[0], RequestType.TPA);
            }
            case "tpahere", "tpalai" -> {
                if (args.length != 1) {
                    tell(player, "Su dung: /tpahere <ten nguoi choi>", NamedTextColor.YELLOW);
                    return true;
                }
                sendToNamedPlayer(player, args[0], RequestType.HERE);
            }
            case "tpaccept" -> acceptRequest(player, args);
            case "tpahuy" -> cancelRequests(player);
            case "tpaauto", "tpalientuc" -> {
                boolean enabled = !autoAccept.getOrDefault(player.getUniqueId(), false);
                autoAccept.put(player.getUniqueId(), enabled);
                tell(player, "Tu dong chap nhan TPA: " + (enabled ? "BAT" : "TAT"),
                        enabled ? NamedTextColor.GREEN : NamedTextColor.YELLOW);
            }
            case "dova" -> showHelp(player);
            default -> { return false; }
        }
        return true;
    }

    private void openPlayerDialog(Player viewer, RequestType type) {
        List<Player> online = Bukkit.getOnlinePlayers().stream()
                .filter(target -> !target.getUniqueId().equals(viewer.getUniqueId()))
                .sorted(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER))
                .limit(60)
                .toList();

        if (online.isEmpty()) {
            tell(viewer, "Hien khong co nguoi choi nao khac dang truc tuyen.", NamedTextColor.YELLOW);
            return;
        }

        List<ActionButton> buttons = new ArrayList<>();
        for (Player target : online) {
            UUID targetId = target.getUniqueId();
            String targetName = target.getName();
            DialogAction action = DialogAction.customClick((response, audience) -> {
                if (audience instanceof Player clicker) {
                    Player selected = Bukkit.getPlayer(targetId);
                    if (selected == null) tell(clicker, "Nguoi choi nay khong con truc tuyen.", NamedTextColor.RED);
                    else sendRequest(clicker, selected, type);
                }
            }, ClickCallback.Options.builder().uses(1).build());

            buttons.add(ActionButton.create(
                    Component.text(targetName, NamedTextColor.WHITE),
                    Component.text("Gui yeu cau den " + targetName, NamedTextColor.GRAY),
                    150,
                    action
            ));
        }

        Dialog dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text(
                                type == RequestType.TPA ? "Danh sach nguoi choi - TPA" : "Danh sach nguoi choi - TPAHERE",
                                NamedTextColor.AQUA))
                        .body(List.of(io.papermc.paper.registry.data.dialog.body.DialogBody.plainMessage(
                                Component.text("Chon mot nguoi choi de gui yeu cau.", NamedTextColor.GRAY))))
                        .canCloseWithEscape(true)
                        .build())
                .type(DialogType.multiAction(buttons, null, 3))
        );
        viewer.showDialog(dialog);
    }

    private void sendToNamedPlayer(Player sender, String name, RequestType type) {
        Player target = Bukkit.getPlayerExact(name);
        if (target == null) {
            tell(sender, "Khong tim thay nguoi choi " + name + ".", NamedTextColor.RED);
            return;
        }
        sendRequest(sender, target, type);
    }

    private void sendRequest(Player sender, Player receiver, RequestType type) {
        if (sender.getUniqueId().equals(receiver.getUniqueId())) {
            tell(sender, "Ban khong the gui yeu cau cho chinh minh.", NamedTextColor.RED);
            return;
        }

        TpaRequest request = new TpaRequest(sender.getUniqueId(), receiver.getUniqueId(), type,
                System.currentTimeMillis());

        if (autoAccept.getOrDefault(receiver.getUniqueId(), false)) {
            teleport(request, receiver);
            tell(sender, "Nguoi choi " + receiver.getName() + " da bat tu dong chap nhan.", NamedTextColor.GREEN);
            return;
        }

        requests.computeIfAbsent(receiver.getUniqueId(), key -> new ConcurrentHashMap<>())
                .put(sender.getUniqueId(), request);

        tell(sender, "Da gui yeu cau den " + receiver.getName() + ".", NamedTextColor.GREEN);

        String actionText = type == RequestType.TPA
                ? " da gui yeu cau dich chuyen den ban. "
                : " da gui yeu cau dich chuyen lai cho ho. ";

        Component accept = Component.text("(/tpachapnhan)", NamedTextColor.WHITE)
                .clickEvent(ClickEvent.runCommand("/tpaccept " + sender.getName()));
        Component cancel = Component.text("(/tpahuy)", NamedTextColor.WHITE)
                .clickEvent(ClickEvent.runCommand("/tpahuy"));

        receiver.sendMessage(Component.text(sender.getName(), NamedTextColor.WHITE)
                .append(Component.text(actionText, NamedTextColor.GRAY))
                .append(accept)
                .append(Component.text(" Neu khong muon chap nhan: ", NamedTextColor.GRAY))
                .append(cancel));

        receiver.sendActionBar(Component.text(
                sender.getName() + (type == RequestType.TPA
                        ? " da gui yeu cau dich chuyen den ban"
                        : " da gui yeu cau dich chuyen lai cho ho"),
                NamedTextColor.GRAY));
    }

    private void acceptRequest(Player receiver, String[] args) {
        Map<UUID, TpaRequest> pending = requests.get(receiver.getUniqueId());
        if (pending == null || pending.isEmpty()) {
            tell(receiver, "Ban khong co yeu cau dich chuyen nao.", NamedTextColor.YELLOW);
            return;
        }

        TpaRequest request;
        if (args.length > 0) {
            Player named = Bukkit.getPlayerExact(args[0]);
            request = named == null ? null : pending.get(named.getUniqueId());
        } else if (pending.size() == 1) {
            request = pending.values().iterator().next();
        } else {
            tell(receiver, "Co nhieu yeu cau. Hay dung /tpaccept <ten nguoi choi>.", NamedTextColor.YELLOW);
            return;
        }

        if (request == null) {
            tell(receiver, "Khong tim thay yeu cau cua nguoi choi do.", NamedTextColor.RED);
            return;
        }

        pending.remove(request.sender());
        if (System.currentTimeMillis() - request.createdAt() > REQUEST_LIFETIME_MS) {
            tell(receiver, "Yeu cau nay da het han.", NamedTextColor.RED);
            return;
        }
        teleport(request, receiver);
    }

    private void teleport(TpaRequest request, Player receiver) {
        Player requester = Bukkit.getPlayer(request.sender());
        if (requester == null || !receiver.isOnline()) {
            tell(receiver, "Nguoi gui yeu cau khong con truc tuyen.", NamedTextColor.RED);
            return;
        }

        Player moving = request.type() == RequestType.TPA ? requester : receiver;
        Player destination = request.type() == RequestType.TPA ? receiver : requester;

        moving.teleportAsync(destination.getLocation()).thenAccept(success -> {
            if (success) {
                tell(moving, "Dich chuyen thanh cong.", NamedTextColor.GREEN);
                tell(receiver, "Da chap nhan yeu cau dich chuyen.", NamedTextColor.GREEN);
            } else {
                tell(moving, "Dich chuyen that bai.", NamedTextColor.RED);
            }
        });
    }

    private void cancelRequests(Player player) {
        int removed = 0;
        Map<UUID, TpaRequest> received = requests.remove(player.getUniqueId());
        if (received != null) removed += received.size();

        for (Map<UUID, TpaRequest> map : requests.values()) {
            if (map.remove(player.getUniqueId()) != null) removed++;
        }

        tell(player, removed == 0 ? "Khong co yeu cau nao de huy."
                : "Da huy " + removed + " yeu cau lien quan den ban.", NamedTextColor.YELLOW);
    }

    private void showHelp(Player player) {
        tell(player, "===== DovaTPA | Huong dan =====", NamedTextColor.AQUA);
        tell(player, "/tpa hoac /tpagui - Mo Dialog UI chon nguoi choi", NamedTextColor.WHITE);
        tell(player, "/tpa <ten> - Gui yeu cau truc tiep", NamedTextColor.WHITE);
        tell(player, "/tpahere <ten> hoac /tpalai <ten> - Moi nguoi choi den cho ban", NamedTextColor.WHITE);
        tell(player, "/tpaccept [ten] | /yes | /tpachapnhan - Chap nhan", NamedTextColor.WHITE);
        tell(player, "/tpahuy | /no - Huy cac yeu cau", NamedTextColor.WHITE);
        tell(player, "/tpaauto hoac /tpalientuc - Bat/tat tu dong chap nhan", NamedTextColor.WHITE);
        tell(player, "Yeu cau tu dong het han sau 60 giay.", NamedTextColor.GRAY);
    }

    private void tell(Player player, String message, NamedTextColor color) {
        player.sendMessage(Component.text(message, color));
    }
}
